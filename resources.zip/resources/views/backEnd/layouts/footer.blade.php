<div class="row-fluid">
    <div id="footer" class="span12">Copyright ©2020 MedstepBd All rights reserved.</div>
</div>
